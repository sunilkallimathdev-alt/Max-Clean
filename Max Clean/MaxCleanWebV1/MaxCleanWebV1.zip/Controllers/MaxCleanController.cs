﻿using API.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using static MaxCleanWebV1.Models.StaticData;

namespace MaxCleanWebV1.Controllers
{
    public class MaxCleanController : Controller
    {
        // GET: MaxClean
       

        public ActionResult Home()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Services()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        public JsonResult RegisterContactUsDetails(string name,string mobile, string email,string msg)
        {
            try
            {
                ContactUs_Model oContactUs_Model = new ContactUs_Model();
                oContactUs_Model.ContactName = name;
                oContactUs_Model.MobileNumber = mobile;
                oContactUs_Model.EmailID = email;
                oContactUs_Model.Query = msg;
                WebClient client = new WebClient();
                client.Headers[HttpRequestHeader.Accept] = "application/json";
                client.Headers[HttpRequestHeader.ContentType] = "application/json";

         
                //var res = (JObject)JsonConvert.DeserializeObject(client.UploadString(Static_Data.BaseURL + "ContactUs", "POST", Objcontactus));
                //return res;

                var res = (JObject)JsonConvert.DeserializeObject(client.UploadString(Static_Data.BaseURL + "ContactUs", "POST", JsonConvert.SerializeObject(oContactUs_Model)));

                //var result = JsonConvert.SerializeObject(res);

                int result = Convert.ToInt32(res["StatusCode"]);

                if (result == 200)
                    return Json(new { result = "Success" });
                else
                    return Json(new { result = "NotFound" });
            }
            catch (Exception)
            {

                return null;
            }
        }


        public dynamic LoginDetails(string userName, string password)
        {

            try
            {
                Customer_Model oCustomer_Model = new Customer_Model();
                oCustomer_Model.MobileNumber = userName;
                oCustomer_Model.Password = password;
                WebClient client = new WebClient();
                client.Headers[HttpRequestHeader.Accept] = "application/json";
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                var result  = client.UploadString(Static_Data.BaseURL + "CustomerLogin", "POST", JsonConvert.SerializeObject(oCustomer_Model));
                var res = (JObject)JsonConvert.DeserializeObject(result);
                int ststuscode = Convert.ToInt32(res["StatusCode"]);
                if (ststuscode == 200)
                {
                    //DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(BlogSite));
                    //BlogSite bsObj2 = (BlogSite)deserializer.ReadObject(ms);
                   // Customer_Model loginCustomer_Model = JsonConvert.DeserializeObject<Customer_Model>(result);
                    Customer_Model loginCustomer_Model= res["ObjectResult"].ToObject<Customer_Model> ();
                    Session.Clear();
                    Session.RemoveAll();
                    Session["Users"] = loginCustomer_Model;                
                }

                return res;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public dynamic RegisterCustomer(string ObjCustomer)
        {

            try
            {
                WebClient client = new WebClient();
                client.Headers[HttpRequestHeader.Accept] = "application/json";
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                var res = (JObject)JsonConvert.DeserializeObject(client.UploadString(Static_Data.BaseURL + "Customer", "POST", ObjCustomer));
                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}